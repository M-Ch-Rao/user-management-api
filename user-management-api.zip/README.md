# User Management API 👤

A simple backend project built with **Java, Spring Boot, and H2 Database**.  
This project demonstrates how backend APIs work with a database to manage users.  

---

## Features
- Add a new user  
- Get all users  
- Get user by ID  
- Delete user  

---

## Example Data (Users Table)
| ID | Name   | Email             |
|----|--------|-------------------|
| 1  | Rahul  | rahul@gmail.com   |
| 2  | Priya  | priya@gmail.com   |
| 3  | Arjun  | arjun@yahoo.com   |

---

## API Endpoints
- `POST /users` → Add user  
  Example: `{ "name": "Rahul", "email": "rahul@gmail.com" }`
- `GET /users` → Get all users  
- `GET /users/{id}` → Get user by ID  
- `DELETE /users/{id}` → Delete user  

---

## Tech Stack
- Java  
- Spring Boot  
- H2 Database (in-memory SQL DB)  
- JPA (Hibernate ORM)  

---

## How to Run
1. Clone this repo.  
2. Run:
   ```bash
   mvn spring-boot:run
   ```
3. Visit:
   - `http://localhost:8080/users` (list all users)  
   - `http://localhost:8080/users/1` (get user by ID)  
